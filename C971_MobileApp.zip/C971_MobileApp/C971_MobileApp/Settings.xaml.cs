namespace C971_MobileApp;


public partial class Settings : ContentPage
{
	public Settings()
	{
		InitializeComponent();

		Switch @switch = new Switch {  OnColor = Colors.Blue, ThumbColor = Colors.LightBlue };


	}
}